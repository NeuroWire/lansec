import os
import subprocess
import logging
import csv
import json
import sqlite3
import yaml
from scapy.all import *
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

# ANSI color codes
class Color:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'

def create_log_directory():
    log_dir = "/var/log/LanSec/"
    os.makedirs(log_dir, exist_ok=True)  # Create directory if it doesn't exist
    return log_dir

def show_splash_screen():
    banner_text = subprocess.check_output(["figlet", "-f", "slant", "LanSec"], text=True)
    print(Color.HEADER + banner_text + Color.ENDC)
    input("Press Enter to continue...")

def setup_logger(pcap_file, output_format):
    log_dir = create_log_directory()
    if output_format == "html":
        log_file = os.path.join(log_dir, f'{os.path.splitext(os.path.basename(pcap_file))[0]}.html')
    else:
        log_file = os.path.join(log_dir, f'{os.path.splitext(os.path.basename(pcap_file))[0]}.{output_format}')
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s: %(message)s', filename=log_file)
    return log_file

def process_pcap(file_path, analyze_ipv4=True, analyze_ipv6=True):
    try:
        log_file = setup_logger(file_path, output_format="text")  # Always create a text log for processing
        logging.info(f'Reading pcap file: {file_path}')

        print(Color.GREEN + "Reading file..." + Color.ENDC)

        # Reading the pcap file and extracting addresses using scapy
        packets = rdpcap(file_path)
        unique_ipv4_addresses = set(packet[IP].src for packet in packets if IP in packet) if analyze_ipv4 else set()
        unique_ipv6_addresses = set(packet[IPv6].src for packet in packets if IPv6 in packet) if analyze_ipv6 else set()

        print(Color.GREEN + "\nAnalysis completed. Summary:" + Color.ENDC)
        if analyze_ipv4:
            print(f" - {Color.YELLOW}Unique IPv4 addresses:{Color.ENDC} {len(unique_ipv4_addresses)}")
        if analyze_ipv6:
            print(f" - {Color.YELLOW}Unique IPv6 addresses:{Color.ENDC} {len(unique_ipv6_addresses)}")

        return unique_ipv4_addresses, unique_ipv6_addresses, log_file

    except FileNotFoundError as e:
        logging.error(f'Error: {e}')
        print(f'{Color.RED}Error:{Color.ENDC} {e}. Please check the file path and try again.')

    except Exception as e:
        logging.error(f'An unexpected error occurred: {e}')
        print(f'{Color.RED}An unexpected error occurred:{Color.ENDC} {e}')

def save_csv_report(unique_ipv4_addresses, unique_ipv6_addresses, log_file):
    with open(log_file, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['IPv4 Addresses'])
        for ipv4 in unique_ipv4_addresses:
            writer.writerow([ipv4])
        writer.writerow(['IPv6 Addresses'])
        for ipv6 in unique_ipv6_addresses:
            writer.writerow([ipv6])
    print(f"CSV report saved to {Color.BLUE}{log_file}{Color.ENDC}")

def save_json_report(unique_ipv4_addresses, unique_ipv6_addresses, log_file):
    report_data = {
        "IPv4 Addresses": list(unique_ipv4_addresses),
        "IPv6 Addresses": list(unique_ipv6_addresses)
    }
    with open(log_file, 'w') as jsonfile:
        json.dump(report_data, jsonfile, indent=4)
    print(f"JSON report saved to {Color.BLUE}{log_file}{Color.ENDC}")

def save_xml_report(unique_ipv4_addresses, unique_ipv6_addresses, log_file):
    with open(log_file, 'w') as xmlfile:
        xmlfile.write('<?xml version="1.0" encoding="UTF-8"?>\n')
        xmlfile.write('<report>\n')
        xmlfile.write('<ipv4_addresses>\n')
        for ipv4 in unique_ipv4_addresses:
            xmlfile.write(f'<address>{ipv4}</address>\n')
        xmlfile.write('</ipv4_addresses>\n')
        xmlfile.write('<ipv6_addresses>\n')
        for ipv6 in unique_ipv6_addresses:
            xmlfile.write(f'<address>{ipv6}</address>\n')
        xmlfile.write('</ipv6_addresses>\n')
        xmlfile.write('</report>')
    print(f"XML report saved to {Color.BLUE}{log_file}{Color.ENDC}")

def save_sqlite_report(unique_ipv4_addresses, unique_ipv6_addresses, log_file):
    conn = sqlite3.connect(log_file)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS addresses (id INTEGER PRIMARY KEY, address TEXT)''')
    for ipv4 in unique_ipv4_addresses:
        cursor.execute('''INSERT INTO addresses (address) VALUES (?)''', (ipv4,))
    for ipv6 in unique_ipv6_addresses:
        cursor.execute('''INSERT INTO addresses (address) VALUES (?)''', (ipv6,))
    conn.commit()
    conn.close()
    print(f"SQLite report saved to {Color.BLUE}{log_file}{Color.ENDC}")

def save_yaml_report(unique_ipv4_addresses, unique_ipv6_addresses, log_file):
    report_data = {
        "IPv4 Addresses": list(unique_ipv4_addresses),
        "IPv6 Addresses": list(unique_ipv6_addresses)
    }
    with open(log_file, 'w') as yamlfile:
        yaml.dump(report_data, yamlfile, default_flow_style=False)
    print(f"YAML report saved to {Color.BLUE}{log_file}{Color.ENDC}")

def save_pdf_report(unique_ipv4_addresses, unique_ipv6_addresses, log_file):
    c = canvas.Canvas(log_file, pagesize=letter)
    c.setFont("Helvetica", 12)
    c.drawString(100, 750, "IPv4 Addresses")
    c.drawString(100, 730, "------------")
    y_position = 710
    for ipv4 in unique_ipv4_addresses:
        c.drawString(100, y_position, ipv4)
        y_position -= 20
    c.drawString(100, y_position, "IPv6 Addresses")
    c.drawString(100, y_position - 20, "------------")
    y_position -= 40
    for ipv6 in unique_ipv6_addresses:
        c.drawString(100, y_position, ipv6)
        y_position -= 20
    c.save()
    print(f"PDF report saved to {Color.BLUE}{log_file}{Color.ENDC}")

def save_report(unique_ipv4_addresses, unique_ipv6_addresses, log_file):
    while True:
        choice = input("\nHow do you want to save the report?\n1. Save as HTML\n2. Save as plain text\n3. Save as CSV\n4. Save as JSON\n5. Save as XML\n6. Save to SQLite\n7. Save as YAML\n8. Save as PDF\nEnter the option number: ")
        if choice == "1":
            output_format = "html"
        elif choice == "2":
            output_format = "txt"
        elif choice == "3":
            output_format = "csv"
        elif choice == "4":
            output_format = "json"
        elif choice == "5":
            output_format = "xml"
        elif choice == "6":
            output_format = "sqlite"
        elif choice == "7":
            output_format = "yaml"
        elif choice == "8":
            output_format = "pdf"
        else:
            print(f"{Color.RED}Invalid option. Please choose a valid option.{Color.ENDC}")
            continue

        log_file = setup_logger(log_file, output_format)
        if output_format == "html":
            # Write HTML report
            # Implement this part as per your requirement
            pass
        elif output_format == "txt":
            # Write plain text report
            # Implement this part as per your requirement
            pass
        elif output_format == "csv":
            save_csv_report(unique_ipv4_addresses, unique_ipv6_addresses, log_file)
        elif output_format == "json":
            save_json_report(unique_ipv4_addresses, unique_ipv6_addresses, log_file)
        elif output_format == "xml":
            save_xml_report(unique_ipv4_addresses, unique_ipv6_addresses, log_file)
        elif output_format == "sqlite":
            save_sqlite_report(unique_ipv4_addresses, unique_ipv6_addresses, log_file)
        elif output_format == "yaml":
            save_yaml_report(unique_ipv4_addresses, unique_ipv6_addresses, log_file)
        elif output_format == "pdf":
            save_pdf_report(unique_ipv4_addresses, unique_ipv6_addresses, log_file)
        break

def show_menu():
    print("\nChoose an option:")
    print(f"1. {Color.BLUE}Analyze IPv4 addresses{Color.ENDC}")
    print(f"2. {Color.BLUE}Analyze IPv6 addresses{Color.ENDC}")
    print(f"3. {Color.BLUE}Analyze both IPv4 and IPv6 addresses{Color.ENDC}")
    print(f"4. {Color.BLUE}Exit{Color.ENDC}")

def main():
    show_splash_screen()

    create_log_directory()  # Create the log directory when the script starts

    while True:
        show_menu()
        choice = input("Enter the option number: ")

        if choice == "1":
            file_path = input("Enter the path to the pcap file: ")
            ipv4, ipv6, log_file = process_pcap(file_path, analyze_ipv4=True, analyze_ipv6=False)
            save_report(ipv4, ipv6, log_file)
        elif choice == "2":
            file_path = input("Enter the path to the pcap file: ")
            ipv4, ipv6, log_file = process_pcap(file_path, analyze_ipv4=False, analyze_ipv6=True)
            save_report(ipv4, ipv6, log_file)
        elif choice == "3":
            file_path = input("Enter the path to the pcap file: ")
            ipv4, ipv6, log_file = process_pcap(file_path, analyze_ipv4=True, analyze_ipv6=True)
            save_report(ipv4, ipv6, log_file)
        elif choice == "4":
            print("Exiting LanSec. Goodbye!")
            break
        else:
            print(f"{Color.RED}Invalid option. Please choose a valid option.{Color.ENDC}")

if __name__ == "__main__":
    main()
